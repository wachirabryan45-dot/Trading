const wsUrl = 'wss://ws.derivws.com/websockets/v3?app_id=1089';
let ws = null;

let selectedSymbol = '1HZ10V';
let selectedTradeType = null;
let durationSeconds = null;
let timerInterval = null;

const statusDot = document.getElementById("statusDot");
const tradeTypeDisplay = document.getElementById("tradeTypeDisplay");

// Connect to Deriv
function connect(symbol) {
  if (ws) {
    try { ws.close(); } catch {}
  }

  ws = new WebSocket(wsUrl);

  ws.onopen = () => {
    ws.send(JSON.stringify({ ticks: symbol, subscribe: 1 }));

    const dropdown = document.getElementById("volatilitySelect");
    dropdown.value = symbol;
    const selectedOption = dropdown.options[dropdown.selectedIndex];
    document.getElementById("selectedIndex").innerText = selectedOption.text;
  };

  ws.onmessage = (msg) => {
    const data = JSON.parse(msg.data);
    if (data.tick && typeof data.tick.quote !== "undefined") {
      const price = Number(data.tick.quote).toFixed(4);
      document.getElementById("livePrice").innerText = price;

      const lastDigit = price.slice(-1);
      analyzeTrade(lastDigit);
    }
  };
}

// Trade analysis
function analyzeTrade(lastDigit) {
  const resultDiv = document.getElementById("analysisResult");
  const digit = parseInt(lastDigit);

  if (!selectedTradeType) {
    resultDiv.innerText = "Select Trade Type...";
    return;
  }

  let result = "";

  switch (selectedTradeType) {
    case "even":
      result = digit % 2 === 0 ? "Even ✔" : "Odd ✘";
      break;
    case "odd":
      result = digit % 2 !== 0 ? "Odd ✔" : "Even ✘";
      break;
    case "over":
      result = digit >= 5 ? `Over ✔ (${digit})` : `Under ✘ (${digit})`;
      break;
    case "under":
      result = digit <= 4 ? `Under ✔ (${digit})` : `Over ✘ (${digit})`;
      break;
    case "matches":
      result = `Last digit: ${digit} (Matches mode active)`;
      break;
    case "differs":
      result = `Last digit: ${digit} (Differs mode active)`;
      break;
    default:
      result = "Invalid trade type";
  }

  resultDiv.innerText = result;
}

// Timer countdown
function startTimer(seconds) {
  let remaining = seconds;
  const timerDisplay = document.getElementById("timerDisplay");

  clearInterval(timerInterval);

  timerInterval = setInterval(() => {
    let min = Math.floor(remaining / 60);
    let sec = remaining % 60;
    timerDisplay.innerText = `Duration: ${min}:${sec < 10 ? "0" + sec : sec}`;

    if (remaining <= 0) {
      clearInterval(timerInterval);
      timerDisplay.innerText = "Analysis Completed";
      setStatus("red");
      if (ws) {
        try { ws.close(); } catch {}
        ws = null;
      }
    }
    remaining--;
  }, 1000);
}

// Trade type selection
document.getElementById("contractType").addEventListener("change", function () {
  selectedTradeType = this.value;
  tradeTypeDisplay.innerText = `Trade Type: ${this.options[this.selectedIndex].text}`;
});

// Duration selection
document.getElementById("duration").addEventListener("change", function () {
  durationSeconds = parseInt(this.value);
});

// Market change
document.getElementById("volatilitySelect").addEventListener("change", function () {
  selectedSymbol = this.value;
  connect(selectedSymbol);
});

// Start analysis
document.getElementById("startBtn").addEventListener("click", () => {
  if (!durationSeconds) {
    alert("Please select a duration before starting analysis.");
    return;
  }
  connect(selectedSymbol);
  startTimer(durationSeconds);
  setStatus("green", true);
});

// Stop analysis
document.getElementById("stopBtn").addEventListener("click", () => {
  if (ws) {
    try { ws.close(); } catch {}
    ws = null;
  }
  clearInterval(timerInterval);
  document.getElementById("timerDisplay").innerText = "Stopped";
  setStatus("red", false);
});

// Status dot updater
function setStatus(color, isPulsing = false) {
  statusDot.className = `status-dot ${color}`;
  if (isPulsing && color === "green") {
    statusDot.classList.add("pulse");
  }
}

// On load
document.addEventListener("DOMContentLoaded", () => {
  connect(selectedSymbol);
  setStatus("red");
});
